
<html>
<head>
</head>
<style>
body, html {
  height: 100%;
  margin: 0;
  font-family: Arial;
}

/* Style tab links */
.tablink {
  background-color: #555;
  color: white;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  font-size: 17px;
  width: 25%;
}

.tablink:hover {
  background-color: #777;
}

/* Style the tab content (and add height:100% for full page content) */
.tabcontent {
  color: white;
  display: none;
  padding: 100px 20px;
  height: 100%;
  animation: fadeEffect 1s; /* Fading effect takes 1 second */
}
/* Go from zero to full opacity */
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}
#Home {background-color: #6E130E;}
#Profile {background-color: #083503;}
#Enrolled {background-color: #070E2E;}
#Addcourse {background-color: #5D560C;}
#frm{  
    
    width:10%;  
    border-radius: 2px;  
    margin: 120px auto;  
      
    padding: 50px;  
}  
#frm2{  
    
    width:10%;  
    border-radius: 2px;  
    margin: 120px auto;  
      
    padding: 50px;  
} 
#btn{  
    color: #FFFFE0;  
    background: #8B0000;  
    padding: 15px;  
    margin-left:20%;  
}
#btn1{  
    color: #FFFFE0;  
    background: #8B0000;  
    padding: 15px;  
    margin-left:20%;  
}
</style>
<script>
function openPage(pageName, elmnt, color) {
  // Hide all elements with class="tabcontent" by default */
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Remove the background color of all tablinks/buttons
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }

  // Show the specific tab content
  document.getElementById(pageName).style.display = "block";

  // Add the specific color to the button used to open the tab content
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>


<body style="background:url(b2);background-repeat:no-repeat;background-size=100% 100%">



	<button class="tablink" onclick="openPage('Home', this, 'red')" id="defaultOpen">Home</button>
	<button class="tablink" onclick="openPage('Profile', this, 'green')" >Profile</button>
	<button class="tablink" onclick="openPage('Enrolled', this, 'blue')">My Courses</button>
	<button class="tablink" onclick="openPage('Addcourse', this, 'orange')">Add Course</button>

	<div id="Home" class="tabcontent">
	<?php
	
	    $host = "localhost";  
	    $usr = "root";  
	    $pwd = '';  
	    $db_name = "College_db";  
	      
	    $con = mysqli_connect($host, $usr, $pwd, $db_name);  
	    
	    if(mysqli_connect_errno()) {  
		die("Failed to connect with MySQL: ". mysqli_connect_error());  
	    }   
	    $username = $_POST['user'];  
	    $password = $_POST['pass'];  
	  
	      
		//to prevent from mysqli injection  
		$username = stripcslashes($username);  
		$password = stripcslashes($password);
		
		$username = mysqli_real_escape_string($con, $username);  
		$password = mysqli_real_escape_string($con, $password);  
	      	$id=$username;
	      	
		$sql = "select *from Flogin where UserId = '$username' and Password = '$password'";  
		$result = mysqli_query($con, $sql);  
		$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
		$count = mysqli_num_rows($result);
		 if($count == 1)
		 {  
			 $sql = "select *from Faculty where fid = '$id' ";  
			$result = mysqli_query($con, $sql);  
			$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
			$name=$row['fname'];
		
			echo "<h1><center> Welcome '$name' </center></h1>";
		 
        
              ?>
        </div>

	<div id="Profile" class="tabcontent">
	<?php
		
			echo "<h2 style='color:yellow';><center>'$name' Profile: </h2>";
			$snum=$row['fid'];
			$name=$row['fname'];
			$dep=$row['deptid'];
			
			echo "<b>Falulty id:: '$snum'  </b><br>";
			echo "<b><br>Faculty Name:'$name' </b><br>";	 		
			echo "<b><br>Dept Id  : '$dep'</b><br>";
			
		
 	?>
	</div>

	<div id="Enrolled" class="tabcontent">
    		<?php
    
        
			echo "<h2 style='color:#B5F909';><center>'$name'Teach Courses: </h2>";
			$sql = "select name from Class where fid = '$id' ";  
			$result = mysqli_query($con, $sql);  
			

			while ($row = mysqli_fetch_assoc($result)) 
			{
				echo '<b>';
				echo $row['name'];
				echo "<br> </br>";
				
				  
			}
			
		      
    		?>
	    	 <form action="drop1.php" method="post">
		<br>
	
		<h3 style="color:yellow;">Drop Course: </h4>
		<br>
		<input type="hidden" name="id" value="<?php echo $id;?>">
		<select name="subject">
		<option value="" disabled selected>Select Course</option>
		<?php
		$query = "select name from Class where fid = $id;";
		$result = mysqli_query($con,$query);
		while($row = mysqli_fetch_assoc($result))
		{
		?>
		<option value = "<?php echo $row['name'];?>"><?php echo $row['name'];?></option>
		<?php
		}
		?>
		</select>

		<br>
		<input type= "submit" id="btn" value = "Drop Course">
	</form>
    
	</div>

	<div id="Addcourse" class="tabcontent">
	<?php
    
        
	echo "<h2 style='color:#B5F909';><center>Available Courses: </h2>";
	$sql = "select name from Class where fid= '$id') ";  
	$result = mysqli_query($con, $sql);  
	

	while ($row = mysqli_fetch_assoc($result)) 
	{
		echo '<b>';
		echo $row['name'];
		echo "<br> </br>";
		
		  
	}
			
		      
    	?>
	
	<div id="frm2">
	<form name="f2" action="Add1.php" method="POST">
	<br>
	<h3 style="color:red;">Add Course: </h3>
	<br>
	<input type="hidden" name="id" value="<?php echo $id;?>">
	 <p> 
        <label ><b>Course Name</b></label>
        <input type="text" placeholder="Enter Course Name" name="name" >
	</p>
	<p>
        <label ><b>Meet_at</b></label>
        <input type="text" placeholder="Enter Meeting time" name="meets_at" >
        </p>
        <p>
	<label ><b>Room</b></label>
        <input type="text" placeholder="Enter Room No" name="room" >
        </p>
	<br>
	<p>
	<input type= "submit" id="btn1" value = "Add Course">
	</p>
	</form>
			
		
	</div>	
	</div>
	
	<?php
	}
	else{  
            echo "<h1 align=center style='color:red'> Login failed. Invalid username or password.</h1>";  
        }
        mysqli_close($con);   
	
	?>
	 
   
	

</body>
</html>


