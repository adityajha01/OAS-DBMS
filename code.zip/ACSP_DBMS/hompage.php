<html>
<head>  
<header>
  <h1 align=center style="color:yellow">Welcome to OAS Portal</h1>
</header>
	
</head>
<style>
body{   
       
}  
div {
  opacity: 0.7;
}
#frm{  
    
    width:10%;  
    border-radius: 2px;  
    margin: 120px auto;  
      
    padding: 50px;  
}  
#btn{  
    color: #FFFFE0;  
    background: #8B0000;  
    padding: 15px;  
    margin-left:30%;  
} 
#btn1{  
    color: #FFFFE0;  
    background: #8B0000;  
    padding: 15px;  
    margin-left: 30%;  
}
#btn2{  
    color: #FFFFE0;  
    background: #8B0000;  
    padding: 15px;  
    margin-left: 30%;  
}     

</style>
<body style="background:url(bg1); type="text/css" >

<div id = "frm"> 
  
  <form method="POST" action="flogin.php">
    <input type="submit" id="btn" value="Faculty Login"/>
  </form>
  <form method="POST" action="login.php">
    <input type="submit" id="btn1" value="Student Login"/>
  </form>
  <form method="POST" action="admin.php">
    <input type="submit" id="btn2" value=" Admin Login "/>
  </form>
 </div> 
</body>
</html>
