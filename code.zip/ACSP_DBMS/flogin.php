<html>
<head>  
<header>
  <h1 align=center style="color:#500510 ">Faculty Login</h1>
</header>	
</head>
<style>
body{   
      
}  

#frm{  
    border: solid gray 1px;  
    width:15%;  
    border-radius: 2px;  
    margin: 120px auto;  
      
    padding: 50px;  
}  
#btn{  
    color: #FFFFE0; 
    opacity: 0.8; 
    background: #8B0000;  
    padding: 15px;  
    margin-left:30%;  
}
#btn1{  
    color: #FFFFE0; 
    opacity: 0.8; 
    background: #8B0000;  
    padding: 15px;  
    margin-left:30%;  
}
#user{
	background: #D3D3D3;

}
#pass{

	background: #D3D3D3;
} 


</style> 
<body style="background:url(d5); type="text/css">  
    <div id = "frm">  
        
        <form name="f1" action = "auth1.php" onsubmit = "return validation()" method = "POST">  
            <p>  
                <label style="color:green"> UserID  : </label>  
                <input type = "text" id ="user" name  = "user" />  
            </p> 
            <p>  
                <label style="color:green" > Password: </label>  
                <input type = "password" id ="pass" name  = "pass" />  
            </p><br>
            <p>     
                <input type =  "submit" id = "btn" value = " Login " />  
            </p> 
              
        </form>
        <form name="f2" action = "fsign.php">  
             <p>     
                <input type =  "submit" id = "btn1" value = "Sign up" />  
            </p> 
        
        </form>
          
    </div>  
   
    <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
</body>     
</html>  
