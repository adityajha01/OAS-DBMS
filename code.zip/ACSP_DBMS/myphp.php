<?php
echo <body style="dark grey">;
echo "Hello Aditya";
?>
