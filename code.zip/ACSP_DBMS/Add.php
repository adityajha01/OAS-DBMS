<!DOCTYPE html>


<html>
<head>
 
    <title>Add course</title>
</head>
<style>

*{

  
margin : 0;
padding : 0%; 
box-sizing : order-box;
text-align : center;


}
.container{


margin : 0%;
padding : 0%; 
box-sizing : order-box;
text-align : center;
font-size : 300%;


}
</style>

<body style = "background-image: url(c3);">
<h1>Welcome to Add course</h1>
<br>
<br>
<br>
<br>
<div class = "container">
<?php
$id = $_POST["id"];
$sub = $_POST["subject"];

$host = "localhost";  
$usr = "root";  
$pwd = '';  
$db_name = "College_db";  

$con = mysqli_connect($host, $usr, $pwd, $db_name);  
$query="select * from Enrolled where snum='$id' and cname='$sub'";
$result = mysqli_query($con,$query);
if(mysqli_num_rows($result)>0)
{
	echo "<h4 style='color:red'>Course '$sub' is already Added</h4>";
}
else
{
	$query1="insert into Enrolled values('$id','$sub')";
	$result1 = mysqli_query($con,$query1);
	if($result1)
	{
	    echo "<h4 style='color:green'><center>Course '$sub' added Successfully</h4>";
	}
}

mysqli_close($con);  

?>



</div>
</body>
</html>
