<html>
<head>  
<header>
  <h1 align=center>Welcome to OAS Portal</h1>
</header>
	<link rel = "stylesheet" type = "text/css" href = "style.css"> 
</head>
<body>
<div id = "frm"> 
  <style>
  	background-pic="s1.jpeg";
  </style>
  <form method="POST" action="flogin.php">
    <input type="submit" id="btn" value="Faculty Login"/>
  </form>
  <form method="POST" action="login.php">
    <input type="submit" id="btn1" value="Student Login"/>
  </form>
  <form method="POST" action="admin.php">
    <input type="submit" id="btn2" value="Admin Login"/>
  </form>
 </div> 
</body>
</html>
