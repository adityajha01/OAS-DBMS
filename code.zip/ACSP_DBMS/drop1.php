<!DOCTYPE html>


<html>
<head>
    
</head>
<style>

*{

  
margin : 0;
padding : 0%; 
box-sizing : order-box;
text-align : center;


}
.container{


margin : 0%;
padding : 0%; 
box-sizing : order-box;
text-align : center;
font-size : 300%;


}
</style>
<body style ="background-image: url(c3);">
<h1>Welcome To Drop Course</h1>
<br>
<br>
<br>
<div class = "container">
<?php



$id = $_POST["id"];
$subject = $_POST["subject"];

$host = "localhost";  
$usr = "root";  
$pwd = '';  
$db_name = "College_db";  

$con = mysqli_connect($host, $usr, $pwd, $db_name);  
$query = "select name from Class where fid = '$id'";
$query1 = "delete from Class where fid = '$id' and name = '$subject'";


$result =  mysqli_query($con,$query);
$c = 0;
while($row = mysqli_fetch_assoc($result))
{
if($subject == $row['name'])
{
$c =$c + 1;
break ;
}
}
if($c == 0)
echo "<h4 style='color:red'><center>You are not Teaching this Course</h4>";
else{

$result2 =  mysqli_query($con,$query1);
if($result2)
echo "<h4 style='color:green'><center>Course '$subject' dropped successfully<h4>";
else
echo mysqli_error($con);


}
mysqli_close($con);  

?>
</div>
</body>
</html>
